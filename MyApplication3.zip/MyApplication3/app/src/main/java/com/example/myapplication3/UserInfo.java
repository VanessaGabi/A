package com.example.myapplication3;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class UserInfo extends AppCompatActivity {

    TextView textViewName;
    TextView textViewSexo;
    TextView textViewIdade;
    TextView textViewRa;
    TextView textViewCurso;

    private ImageView imageViewFoto;


    @Override
    protected void onCreate(Bundle saveInstance){
        super.onCreate(saveInstance);
        setContentView(R.layout.activity_user_info);

        String filename="imagem.png";
        File filePath= new File(getFilesDir(),filename);

        Bitmap originalBitmap= BitmapFactory.decodeFile(filePath.getAbsolutePath());
        Bitmap resizedBitmap= Bitmap.createScaledBitmap(originalBitmap,1024,1024,false);


        Intent intent = getIntent();

        String name = intent.getStringExtra("name");
        String sexo = intent.getStringExtra("sex");
        String idade = intent.getStringExtra("idade");
        String ra = intent.getStringExtra("ra");
        String curso = intent.getStringExtra("curso");
        String imageBitmap=intent.getParcelableArrayExtra("imageBitmap");

        imageViewFoto.setImageBitmap(resizedBitmap);


        imageViewFoto= findViewById(R.id.imageViewFoto);
        textViewName = findViewById(R.id.textViewName);
        textViewSexo = findViewById(R.id.textViewSex);
        textViewIdade = findViewById(R.id.textViewIdade);
        textViewRa = findViewById(R.id.textViewRA);
        textViewCurso = findViewById(R.id.textViewCurso);

        textViewName.setText("Nome:"+ name);
        textViewSexo.setText("Sexo:"+sexo);
        textViewIdade.setText("Idade:"+idade);
        textViewRa.setText("RA:"+ra);
        textViewCurso.setText("Curso:"+curso);




    }
    public void Voltar(){
        finish();
    }
}