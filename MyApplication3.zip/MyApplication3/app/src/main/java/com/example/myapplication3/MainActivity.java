package com.example.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private EditText campoNome;
    private EditText campoIdade;
    private EditText campoRA;
    private RadioGroup radioGroupSex;
    private EditText campoCurso;
    private Button botaoEnviar;
    private Button botaoFoto;
    private static final int REQUEST_IMAGE_CAPTUR = 1;

    private Bitmap imageBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campoNome=findViewById(R.id.campoNome);
        campoIdade=findViewById(R.id.campoIdade);
        campoRA=findViewById(R.id.campoRA);
        radioGroupSex=findViewById(R.id.radioGroupSex);
        campoCurso=findViewById(R.id.campoCurso);
        botaoEnviar=findViewById(R.id.botaoEnviar);
        botaoFoto=findViewById(R.id.botaoFoto);

        botaoFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentTiraFoto();
            }
        });
        botaoEnviar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String name = campoNome.getText().toString().trim();
                String idade = campoIdade.getText().toString().trim();
                String RA = campoRA.getText().toString().trim();
                String curso = campoCurso.getText().toString().trim();
                Bitmap foto = imageBitmap;

                int radioID = radioGroupSex.getCheckedRadioButtonId();
                String sexo = "";
                if(radioID !=-1){
                    RadioButton radioButtonSex = findViewById(radioID);
                    sexo = radioButtonSex.getText().toString();
                }
                Intent intent = new Intent(MainActivity.this, UserInfo.class);
                intent.putExtra("nome", name);
                intent.putExtra("idade", idade);
                intent.putExtra("RA", RA);
                intent.putExtra("sexo", sexo);
                intent.putExtra("curso", curso);
                intent.putExtra("foto", (Parcelable) null);
                startActivity(intent);

            }
        });
    }
    public void IntentTiraFoto(){
        Intent intentTiraFoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intentTiraFoto.resolveActivity(getPackageManager())!= null){
            startActivityForResult(intentTiraFoto, REQUEST_IMAGE_CAPTUR);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_IMAGE_CAPTUR && resultCode == RESULT_OK){
            Bundle extras = data.getExtras();

            imageBitmap = (Bitmap) extras.get("data");
            String filename = "image.png";
            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
                outputStream.close();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}